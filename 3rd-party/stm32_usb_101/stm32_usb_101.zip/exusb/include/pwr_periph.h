#ifndef _PWR_PERIPH_H
#define _PWR_PERIPH_H 1

void PowerLEDconfigure(void);
void PowerLEDon(void);
void PowerLEDoff(void);
int  PowerLEDstate(void);
void WakeupButtonConfigure(void);

#endif
