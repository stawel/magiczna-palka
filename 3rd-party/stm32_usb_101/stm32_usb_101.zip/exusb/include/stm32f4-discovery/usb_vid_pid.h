#ifndef _USB_VID_PID_H
#define _USB_VID_PID_H 1

#define VID 0x0483
#define PID 0x5750

#endif
