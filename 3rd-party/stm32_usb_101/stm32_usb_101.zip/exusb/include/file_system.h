#ifndef _FILE_SYSTEM_H
#define _FILE_SYSTEM_H 1

int FileSystemMount(void);
int FileSystemUmount(void);

#endif
