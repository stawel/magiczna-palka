#ifndef _DELAY_H
#define _DELAY_H 1

void Delay(volatile unsigned);

#endif
