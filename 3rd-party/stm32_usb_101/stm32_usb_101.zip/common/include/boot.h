#ifndef _BOOT_DEF_H
#define _BOOT_H 1

#include <usb_def.h>

void GetBootParams(int *, usb_speed_t *, usb_phy_t *);

#endif
