#ifndef _USB_INTERRUPT_H
#define _USB_INTERRUPT_H 1

void USBglobalInterruptHandler(void);

#endif
