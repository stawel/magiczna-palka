#ifndef _AUXILIARY_H
#define _AUXILIARY_H 1

static inline unsigned long min(unsigned long x, unsigned long y) {
  return x <= y ? x : y;
}

#endif
