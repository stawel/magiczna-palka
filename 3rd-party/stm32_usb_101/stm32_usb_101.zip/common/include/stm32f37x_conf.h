#ifndef _STM32F37X_CONF_H
#define _STM32F37X_CONF_H 1

#define assert_param(expr) ((void)0)

#endif
