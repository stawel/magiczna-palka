#ifndef _BOARD_INIT_H
#define _BOARD_INIT_H 1

void AllPinsDisable(void);
int ClockConfigure(int);
int ClockReenable(void);

#endif
