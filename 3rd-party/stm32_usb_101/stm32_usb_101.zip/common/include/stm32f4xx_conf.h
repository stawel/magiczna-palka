#ifndef _STM32F4XX_CONF_H
#define _STM32F4XX_CONF_H 1

#define assert_param(expr) ((void)0)

#endif
