#include <lcd.h>

int LCDconfigure() {
  return 0;
}

void LCDclear(void) {
}

void LCDgoto(int textLine, int charPos) {
}

void LCDputchar(char c) {
}

void LCDputcharWrap(char c) {
}
